<?php

return [
    'name' => 'Subscription'
];
