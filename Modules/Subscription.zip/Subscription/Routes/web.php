<?php

use Modules\Subscription\Http\Controllers\SubscriptionController;
use Modules\Subscription\Http\Controllers\PackageController;
use Modules\Subscription\Http\Controllers\PackageDurationTypeController;
use Modules\Subscription\Http\Controllers\InstructorSubscriptionController;
use Modules\Subscription\Http\Controllers\OrganizationSubscriptionController;
use Modules\Subscription\Http\Controllers\StudentSubscriptionController;
use Modules\Subscription\Http\Controllers\Frontend\PackageSubscriptionController;
use Modules\Subscription\Http\Controllers\PackageCheckoutController;

// Route::prefix('subscription')->group(function() {
//     Route::get('/', 'SubscriptionController@index');
// });

// admin settings routes
Route::prefix('admin')->middleware(['auth.routes'])->group(function () {
    Route::controller(PackageController::class)->group(function () {
        // package routes
        Route::prefix('package')->group(function () {
            Route::get('/', 'index')->name('subscription.admin.package.index')->middleware('PermissionCheck:package_read');
            Route::get('/create', 'create')->name('subscription.admin.package.create')->middleware('PermissionCheck:package_create');
            Route::post('/store', 'store')->name('subscription.admin.package.store')->middleware('PermissionCheck:package_store');
            Route::get('/show/{slug}', 'show')->name('subscription.admin.package.show')->middleware('PermissionCheck:package_read');
            Route::get('/edit/{id}', 'edit')->name('subscription.admin.package.edit')->middleware('PermissionCheck:package_update');
            Route::put('/update/{id}', 'update')->name('subscription.admin.package.update')->middleware('PermissionCheck:package_update');
            Route::get('/delete/{id}', 'destroy')->name('subscription.admin.package.destroy')->middleware('PermissionCheck:package_delete');
        });
        // package purchase list routes
        Route::prefix('package_purchase')->group(function () {
            Route::get('/', 'indexPackagePurchase')->name('subscription.admin.package_purchase.index')->middleware('PermissionCheck:package_purchase_read');
            Route::get('/invoice/{id}', 'packagePurchaseInvoice')->name('subscription.admin.package_purchase.invoice')->middleware('PermissionCheck:package_purchase_invoice');
            Route::get('/history/{id}', 'packagePurchaseHistory')->name('subscription.admin.package_purchase.history')->middleware('PermissionCheck:package_purchase_history');
        });
    });
    Route::controller(PackageDurationTypeController::class)->group(function () {
        // package duration type routes
        Route::prefix('package_duration_type')->group(function () {
            Route::get('/', 'index')->name('subscription.admin.package_duration_type.index')->middleware('PermissionCheck:package_duration_type_read');
            Route::get('/create', 'create')->name('subscription.admin.package_duration_type.create')->middleware('PermissionCheck:package_duration_type_create');
            Route::post('/store', 'store')->name('subscription.admin.package_duration_type.store')->middleware('PermissionCheck:package_duration_type_store');
            Route::get('/edit/{id}', 'edit')->name('subscription.admin.package_duration_type.edit')->middleware('PermissionCheck:package_duration_type_update');
            Route::put('/update/{id}', 'update')->name('subscription.admin.package_duration_type.update')->middleware('PermissionCheck:package_duration_type_update');
            Route::get('/delete/{id}', 'destroy')->name('subscription.admin.package_duration_type.destroy')->middleware('PermissionCheck:package_duration_type_delete');
        });
    });

    Route::controller(SubscriptionController::class)->group(function () {
        // course approval routes
        Route::prefix('package_course')->group(function () {
            Route::get('/requested', 'requestedIndex')->name('subscription.admin.requested_course')->middleware('PermissionCheck:requested_course_list');
            Route::get('/approved', 'approvedIndex')->name('subscription.admin.approved_course')->middleware('PermissionCheck:approved_course_list');
            Route::get('/rejected', 'rejectedIndex')->name('subscription.admin.rejected_course')->middleware('PermissionCheck:rejected_course_list');
            Route::get('/approve/{course_id}', 'approve')->name('subscription.admin.course.approve')->middleware('PermissionCheck:course_approve');
            Route::get('/reject/{course_id}', 'reject')->name('subscription.admin.course.reject')->middleware('PermissionCheck:course_reject');
        });
    });

    Route::controller(InstructorSubscriptionController::class)->group(function () {
        Route::prefix('subscription')->group(function () {
            Route::get('/package_request', 'adminPackageRequest')->name('subscription.admin.package_request');
            Route::post('/package_request_send', 'adminPackageRequestSend')->name('subscription.admin.package_request_send');
        });
    });
});

// instructor routes
Route::prefix('instructor')->middleware(['instructor', 'auth', 'verified'])->group(function () {
    Route::controller(InstructorSubscriptionController::class)->group(function () {
        Route::prefix('subscription')->group(function () {
            Route::get('/', 'index')->name('subscription.instructor.index');
            Route::get('/package_request', 'packageRequest')->name('subscription.instructor.package_request');
            Route::post('/package_request_send', 'packageRequestSend')->name('subscription.instructor.package_request_send');
        });
    });
});

// organization routes
Route::prefix('organization')->middleware(['organization', 'auth', 'verified'])->group(function () {
    Route::controller(OrganizationSubscriptionController::class)->group(function () {
        Route::prefix('subscription')->group(function () {
            Route::get('/', 'index')->name('subscription.organization.index');
            Route::get('/package_request', 'packageRequest')->name('subscription.organization.package_request');
            Route::post('/package_request_send', 'packageRequestSend')->name('subscription.organization.package_request_send');
        });
    });
});

// student routes
Route::prefix('student')->middleware(['student', 'auth', 'verified'])->group(function () {
    Route::controller(StudentSubscriptionController::class)->group(function () {
        Route::get('/packages', 'packages')->name('student.package');
        Route::get('/package-detail/{slug}', 'packageDetail')->name('student.package.detail');
        Route::get('/package/history/{id}', 'packageHistory')->name('student.package_history');
    });
});

// frontednd routes
Route::get('home/ajax/subscription-packages',  [PackageSubscriptionController::class, 'subscriptionPackages'])->name('homepage.packages'); // homepage data show
Route::get('/package-courses', [PackageSubscriptionController::class, 'courseIndex'])->name('frontend.package.courses');
Route::get('/packages', [PackageSubscriptionController::class, 'packageIndex'])->name('frontend.packages');

// start subscription checkout
Route::controller(PackageCheckoutController::class)->prefix('package/checkout')->middleware('auth')->group(function () {
    Route::get('/', 'index')->name('frontend.package.checkout.index');
    Route::post('payment', 'payment')->name('frontend.package.checkout.payment');
});
// end subscription checkout
