<div class="modal fade boostrap-modal" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content data">
            <div class="modal-body">
                <button type="button" class="close-icon" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ri-close-line" aria-hidden="true"></i>
                </button>
                <div class="custom-modal-body">
                    <form action="{{ $data['url'] }}" class="row p-2" method="post" id="modal_values" enctype="multipart/form-data">
                        @csrf
                        <!-- Title -->
                        <div class="small-tittle-two border-bottom mb-30 pb-8">
                            <h4 class="title text-capitalize font-600">{{ $data['title'] }} </h4>
                        </div>

                        <div class="ot-contact-form mb-24">
                            <label class="ot-contact-label">{{ ___('organization.Course_Title') }}<span class="text-danger">*</span></label>
                            <select class="ot-contact modal_select2 @error('course_id') is-invalid @enderror" id="course_id" name="course_id">
                                <option selected="" disabled="" value="">{{ ___('placeholder.Select_Course_Title') }}</option>
                                @foreach ($data['courses'] as $course)
                                <option value="{{ $course->id }}">{{ $course->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="ot-contact-form mb-24">
                            <label class="ot-contact-label">{{ ___('organization.Package_Name') }}<span class="text-danger">*</span></label>
                            <select class="ot-contact modal_select2 @error('package_id') is-invalid @enderror" id="package_id" name="package_id">
                                <option selected="" disabled="" value="">{{ ___('placeholder.Select_Package_Name') }}</option>
                                @foreach ($data['packages'] as $package)
                                <option value="{{ $package->id }}">{{ $package->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="btn-wrapper d-flex flex-wrap gap-10 mt-20">
                            <button type="button" type="button" class="btn-primary-fill submit_form_btn">{{ @$data['button'] }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('frontend/js/instructor/__modal.min.js') }}"></script>

