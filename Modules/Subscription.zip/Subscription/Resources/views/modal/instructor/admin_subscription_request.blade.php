<div class="modal fade lead-modal" id="lead-modal" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content data">
            <div class="modal-header modal-header-image mb-3">
                <h5 class="modal-title">{{ @$data['title'] }} </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="las la-times" aria-hidden="true"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="{{ $data['url'] }}" class="row p-2" method="post" id="modal_values" enctype="multipart/form-data">
                    @csrf
                    <div class="row mb-3 p-2 mb-3 d-flex justify-content-center">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-xl-12 mb-3">
                                    <label for="course_id" class="form-label">{{ ___('instructor.Course_Title') }} <span class="fillable">*</span></label>
                                    <select class="form-select ot-input modal_select2 @error('course_id') is-invalid @enderror" id="course_id" name="course_id">
                                        <option selected="" disabled="" value="">{{ ___('placeholder.Select_Course_Title') }}</option>
                                        @foreach ($data['courses'] as $course)
                                        <option value="{{ $course->id }}">{{ $course->title }}</option>
                                        @endforeach
                                    </select>
                                    @error('course_id')
                                        <div id="validationServer04Feedback" class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="col-xl-12 mb-3">
                                    <label for="package_id" class="form-label ">{{ ___('instructor.Package_Name') }} <span class="fillable">*</span></label>
                                    <select class="form-select ot-input modal_select2 @error('package_id') is-invalid @enderror" id="package_id" name="package_id">
                                        <option selected="" disabled="" value="">{{ ___('placeholder.Select_Package_Name') }}</option>
                                        @foreach ($data['packages'] as $package)
                                        <option value="{{ $package->id }}">{{ $package->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @error('package_id')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex justify-content-end">
                        <button type="button" onclick="submitMainForm()" class="btn btn-lg btn-primary">{{ @$data['button'] }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('frontend/js/instructor/__modal.min.js') }}"></script>
