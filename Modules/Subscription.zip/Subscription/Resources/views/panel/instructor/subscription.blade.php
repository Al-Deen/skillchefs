@extends('panel.instructor.layouts.master')
@section('title', @$data['title'])
@section('content')

    <!-- Card S t a r t -->
    <div class="dashboared-card mb-24">
        <div class="row g-24">
            <div class="col-xl-6 col-sm-6">
                <div class="single-dashboard-card single-dashboard-card2 carts-bg-two h-calc d-flex align-items-center">
                    <div class="icon">
                        <i class="ri-money-dollar-circle-line"></i>
                    </div>
                    <div class="cat-caption">
                        <p class="pera text-16 font-600">{{ ___('instructor.Total Pending Subscription Course') }}</p>
                        <!-- Counter -->
                        <div class="single-counter mb-15">
                            <p class="currency">
                                {{ shorten_number(@$data['packages_courses']->where('status_id', 3)->count() ?? 0) }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-sm-6">
                <div class="single-dashboard-card single-dashboard-card2 carts-bg-four h-calc d-flex align-items-center">
                    <div class="icon">
                        <i class="ri-money-dollar-circle-line"></i>
                    </div>
                    <div class="cat-caption">
                        <p class="pera text-16 font-600">{{ ___('instructor.Total Approved Subscription Course') }}</p>
                        <!-- Counter -->
                        <div class="single-counter mb-15">
                            <p class="currency">
                                {{ shorten_number(@$data['packages_courses']->where('status_id', 4)->count() ?? 0) }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End-of card -->
    <!-- instructor Courses Start -->
    <section class="instructor-courses">
        <div class="row">
            <!-- Section Tittle -->
            <div class="col-xl-12">
                <div class="section-tittle-two d-flex align-items-center justify-content-between flex-wrap mb-10">
                    <h2 class="title font-600 mb-20">{{ $data['title'] }}</h2>
                    <div class="right d-flex flex-wrap justify-content-between">
                        <!-- Search Box -->
                        <form action="" class="search-box-style mb-20 mr-10">
                            <div class="responsive-search-box">
                                <input class="ot-search " type="text" name="search"
                                    placeholder="{{ ___('placeholder.Search') }}" value="{{ @$_GET['search'] }}">
                                <!-- icon -->
                                <div class="search-icon">
                                    <i class="ri-search-line"></i>
                                </div>
                                <!-- Button -->
                                <button class="search-btn">
                                    {{ ___('frontend.Search') }}
                                </button>
                            </div>
                        </form>
                        <!-- /End -->
                        <div class="search-tab ">
                            <button class="btn-primary-fill main-modal-open" data-url="{{ route('subscription.instructor.package_request') }}">
                                <i class="ri-send-plane-fill"></i> {{ ___('instructor.Send_Package_Request') }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Search -->
        </div>

        <div class="row">
            <div class="col-xl-12">
                <div class="activity-table">
                    <table class="table-responsive">
                        <thead>
                            <tr>
                                <th>{{ ___('common.ID') }}</th>
                                <th>{{ ___('course.Package_Name') }}</th>
                                <th>{{ ___('course.Course_Title') }}</th>
                                <th>{{ ___('common.Category') }}</th>
                                <th>{{ ___('course.Enrollment') }}</th>
                                <th>{{ ___('course.Course_Price') }}</th>
                                <th>{{ ___('course.Status') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($data['packages_courses'] as $packages_course)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $packages_course->package->name }}</td>
                                    <td>
                                        <a href="{{ route('frontend.courseDetails', @$packages_course->course->slug) }}"
                                            class="text-primary">
                                            {{ Str::limit(@$packages_course->course->title, 50) }}
                                        </a>
                                    </td>
                                    <td>{{ @$packages_course->course->category->title }}</td>
                                    <td>{{ @$packages_course->course->totalEnroll() }}</td>
                                    <td>{{ @$packages_course->course->price }}</td>
                                    <td>
                                        @if (@$packages_course->status_id === 3)
                                            <span class="status-pending"> {{ ___('student.Pending') }} </span>
                                        @elseif(@$packages_course->status_id === 4)
                                            <span class="status-success"> {{ ___('student.Approved') }} </span>
                                        @else
                                            <span class="status-danger"> {{ ___('student.Rejected') }} </span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="9" class="text-center">
                                        {{-- No Data Found --}}
                                        <div class="row justify-content-center">
                                            <div class="col-lg-3 col-md-6 col-sm-6">
                                                <div class="not-data-found table-img text-center pt-50 pb-10">
                                                    <img src="{{ @showImage(setting('empty_table'), 'backend/assets/images/no-data.png') }}"
                                                        alt="img" class="w-100 mb-20 w-25">
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <!-- End-of courses  -->
    <!--  pagination start -->
    {!! @$data['packages_courses']->links('frontend.partials.pagination-count') !!}
    <!--  pagination end -->
@endsection
