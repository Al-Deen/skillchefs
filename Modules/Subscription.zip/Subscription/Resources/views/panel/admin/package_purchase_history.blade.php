@extends('backend.master')
@section('title')
    {{ @$data['title'] }}
@endsection
@section('content')
    <div class="page-content">

        {{-- breadecrumb Area S t a r t --}}
        @include('backend.ui-components.breadcrumb', [
            'title' => @$data['title'],
            'routes' => [
                route('dashboard') => ___('common.Dashboard'),
                '#' => @$data['title'],
            ],
            'buttons' => 1,
        ])
        {{-- breadecrumb Area E n d --}}

        <!--  table content start -->
        <div class="table-content table-basic ecommerce-components product-list">
            <div class="card">
                <div class="card-body">
                    <!--  toolbar table start  -->
                    <div class="table-toolbar d-flex flex-wrap gap-2 flex-column flex-xl-row justify-content-center justify-content-xxl-between align-content-center pb-3">
                        <form action="" method="get">
                            <div class="align-self-center">
                                <div
                                    class="d-flex flex-wrap gap-2 flex-column flex-lg-row justify-content-center align-content-center">
                                    <!-- show per page -->
                                    @include('backend.ui-components.per-page')
                                    <!-- show per page end -->

                                    {{-- <div class="align-self-center d-flex gap-2">
                                        <!-- search start -->
                                        <div class="align-self-center">
                                            <div class="search-box d-flex">
                                                <input class="form-control" placeholder="{{ ___('common.search') }}"
                                                    name="{{ ___('common.search') }}" value="{{ @$_GET['search'] }}" />
                                                <span class="icon"><i class="fa-solid fa-magnifying-glass"></i></span>
                                            </div>
                                        </div>
                                        <!-- search end -->

                                        <!-- dropdown action -->
                                        <div class="align-self-center">
                                            <div class="dropdown dropdown-action" data-bs-toggle="tooltip"
                                                data-bs-placement="top" data-bs-title="Filter">
                                                <button type="submit" class="btn-add">
                                                    <span class="icon">{{ ___('common.Filter') }}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div> --}}
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--toolbar table end -->
                    <!--  table start -->
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="thead">
                                <tr>
                                    <th>{{ ___('common.ID') }}</th>
                                    <th>{{ ___('common.Package_Name')}}</th>
                                    <th>{{ ___('common.Package_Duration')}}</th>
                                    <th>{{ ___('ui_element.Price')}}</th>
                                    <th>{{ ___('ui_element.Date')}}</th>
                                    <th>{{ ___('ui_element.Expire_Date')}}</th>
                                    <th>{{ ___('ui_element.Invoice_Number')}}</th>
                                    <th>{{ ___('ui_element.Payment_Method')}}</th>
                                    <th>{{ ___('ui_element.Payment')}}</th>
                                </tr>
                            </thead>
                            <tbody class="tbody">
                                @forelse ($data['purchase_history'] as $key => $purchase_history)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ @$purchase_history->package_name }}</td>
                                        <td>{{ @$purchase_history->package_duration_type->name }}</td>
                                        <td>{{ showPrice(@$purchase_history->amount) }}</td>
                                        <td>{{ showDate(@$purchase_history->start_date) }}</td>
                                        <td>
                                            @if(@$purchase_history->expire_date <= now())
                                                <span class="badge badge-basic-danger-text">{{ showDate(@$purchase_history->expire_date) }}</span>
                                            @elseif(@$purchase_history->expire_date > now() && @$purchase_history->expire_date <= now()->addDays(7))
                                                <span class="badge badge-basic-warning-text">{{ showDate(@$purchase_history->expire_date) }}</span>
                                            @else
                                                <span class="badge badge-basic-success-text">{{ showDate(@$purchase_history->expire_date) }}</span>
                                            @endif
                                        </td>
                                        <td>{{ @$purchase_history->invoice_number }}</td>
                                        <td>{{ @$purchase_history->payment_method }}</td>
                                        <td>
                                            @if(@$purchase_history->status == 'unpaid')
                                            <span class="badge badge-basic-danger-text">{{ ___('common.Unpaid') }}</span>
                                            @elseif(@$purchase_history->status == 'paid')
                                            <span class="badge badge-basic-success-text">{{ ___('common.Paid') }}</span>
                                            @else
                                            <span class="badge badge-basic-info-text">{{ ___('common.Processing') }}</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <!-- empty table -->
                                    @include('backend.ui-components.empty_table', [
                                        'colspan' => '8',
                                        'message' => ___(
                                            'message.Please add a new entity or manage the data table to see the content here'),
                                    ])
                                    <!-- empty table -->
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    <!--  table end -->
                    <!--  pagination start -->
                    @include('backend.ui-components.pagination', ['data' => $data['purchase_history']])
                    <!--  pagination end -->
                </div>
            </div>
        </div>
        <!--  table content end -->
    </div>
@endsection
@push('script')
    @include('backend.partials.delete-ajax')
@endpush
