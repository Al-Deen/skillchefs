@extends('backend.master')
@section('title')
    {{ @$data['title'] }}
@endsection
@section('content')
    <div class="page-content">

        {{-- breadecrumb Area S t a r t --}}
        @include('backend.ui-components.breadcrumb', [
            'title' => @$data['title'],
            'routes' => [
                route('dashboard')                  => ___('common.Dashboard'),
                route('subscription.admin.package.index')      => ___('subscription.Package'),
                '#' => @$data['title'],
            ],
            'buttons' => 0,
        ])
        {{-- breadecrumb Area E n d --}}

        <!--  package edit start -->
        <div class="card ot-card">
            <div class="card-body">
                <form action="{{ route('subscription.admin.package.update', $data['package']->id) }}" enctype="multipart/form-data" method="post">
                    @method('PUT')
                    @csrf
                    {{-- Style Two --}}
                    <div class="row mb-3 row mb-3 d-flex justify-content-center">
                        <div class="col-xl-6 col-md-6 mb-3">
                            <label for="name" class="form-label ">{{ ___('common.Package_Name') }} <span class="fillable">*</span></label>
                            <input type="text" class="form-control ot-input @error('name') is-invalid @enderror" name="name" list="datalistOptions" id="name"
                                value="{{ @$data['package']->name }}" placeholder="{{ ___('placeholder.Enter_Name') }}">
                            @error('name')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-6 col-md-6 mb-3">
                            <label for="package_duration_type_id" class="form-label ">{{ ___('common.Package_Duration') }} <span class="fillable">*</span></label>
                            <select class="form-select ot-input select2 @error('package_duration_type_id') is-invalid @enderror" id="package_duration_type_id" name="package_duration_type_id">
                                <option selected="" disabled="" value="">{{ ___('placeholder.Select_Package_Duration') }}</option>
                                @foreach ($data['type'] as $type)
                                <option value="{{ $type->id }}" {{ $data['package']->package_duration_type_id == $type->id ? 'selected' : '' }}>{{ $type->name }}</option>
                                @endforeach
                            </select>
                            @error('package_duration_type_id')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-12 col-md-12 mb-3 custom-height">
                            <label for="status" class="form-label ">{{ ___('blog.description') }}<span class="fillable">*</span></label>
                            <textarea id="description" name="description" class="ckeditor-editor @error('description') is-invalid @enderror">{{ @$data['package']->description }}</textarea>
                            @error('description')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-4 col-md-6 mb-3">
                            <label for="student_amount" class="form-label">{{ ___('common.Student_Price') }} <span class="fillable">*</span></label>
                            <input type="number" class="form-control ot-input @error('student_amount') is-invalid @enderror" name="student_amount" min="0" value="{{ @$data['package']->student_amount }}"
                                list="datalistOptions" id="student_amount" placeholder="{{ ___('placeholder.Enter_Student_Price') }}">
                            @error('student_amount')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-4 col-md-6 mb-3">
                            <label for="instructor_commission" class="form-label ">{{ ___('common.Instructor_commission') }} <span class="fillable">*</span></label>
                            <input type="number" class="form-control ot-input @error('instructor_commission') is-invalid @enderror" name="instructor_commission" min="0" max="100" list="datalistOptions"
                                value="{{ @$data['package']->instructor_commission }}" id="instructor_amount" placeholder="{{ ___('placeholder.Enter_Instructor_Commission') }}">
                            @error('instructor_commission')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-4 col-md-6 mb-3">
                            <label for="total_course" class="form-label ">{{ ___('common.Total_Course') }}
                                <span class="fillable">*</span></label>
                                <input type="number" class="form-control ot-input @error('total_course') is-invalid @enderror" name="total_course" min="0" max="1000" list="datalistOptions" id="total_course"
                                    value="{{ @$data['package']->total_course }}" placeholder="{{ ___('placeholder.Enter_Total_Course') }}">
                            @error('total_course')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-4 col-md-6 mb-3">
                            <label for="popular" class="form-label ">{{ ___('common.Popular') }}
                                <span class="fillable">*</span></label>
                            <select class="form-select ot-input select2 @error('popular') is-invalid @enderror" id="popular" required name="popular">
                                <option value="0" {{ $data['package']->popular == "0" ? 'selected' : '' }}>{{ ___('common.No') }}</option>
                                <option value="1" {{ $data['package']->popular == "1" ? 'selected' : '' }}>{{ ___('common.Yes') }}</option>
                            </select>
                            @error('popular')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-4 col-md-6 mb-3">
                            <label for="color" class="form-label ">{{ ___('common.Color') }}
                                <span class="fillable">*</span></label>
                                <input type="color" class="form-control ot-input @error('color') is-invalid @enderror" name="color" list="datalistOptions" id="color"
                                    value="{{ @$data['package']->color }}" placeholder="{{ ___('placeholder.Enter_Color') }}">
                            @error('color')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-xl-4 col-md-6 mb-3">
                            <label for="status" class="form-label ">{{ ___('common.Status') }}
                                <span class="fillable">*</span></label>
                            <select class="form-select ot-input select2 @error('status_id') is-invalid @enderror"
                                id="status" required name="status_id">
                                <option value="1" {{ $data['package']->status_id == 1 ? 'selected' : '' }}>{{ ___('common.Active') }}</option>
                                <option value="2" {{ $data['package']->status_id == 2 ? 'selected' : '' }}>{{ ___('common.Inactive') }}</option>
                            </select>
                            @error('status_id')
                                <div id="validationServer04Feedback" class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="col-lg-12 mt-3">
                            <button class="btn btn-lg ot-btn-primary" type="submit">
                                </span>{{ @$data['button'] }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!--  package edit end -->
    </div>
@endsection
