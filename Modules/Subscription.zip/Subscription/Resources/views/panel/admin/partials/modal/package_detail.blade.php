<div class="modal fade lead-modal" id="lead-modal" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content data">
            <div class="modal-header modal-header-image mb-3">
                <h5 class="modal-title">{{ @$data['title'] }} </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="las la-times" aria-hidden="true"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xl-12 col-md-12 mb-3 ">
                        <div>
                            <h6 class="title">{{ ___('subscription.Package_Name') }} :</h5>
                            <p>{{ $data['package_detail']->name }}</p>
                        </div>
                        <div>
                            <h6 class="title">{{ ___('subscription.Package_Duration') }} :</h5>
                            <p>{{ $data['package_detail']->package_duration->name }}</p>
                        </div>
                        <div>
                            <h6 class="title">{{ ___('subscription.Package_Detail') }} :</h5>
                            <p>{!! $data['package_detail']->description !!}</p>
                        </div>
                        <div>
                            <h6 class="title">{{ ___('subscription.Student_Price') }} :</h5>
                            <p>{{ $data['package_detail']->student_amount }}</p>
                        </div>
                        <div>
                            <h6 class="title">{{ ___('subscription.Instructor_Commission') }} :</h5>
                            <p>{{ $data['package_detail']->instructor_commission }}</p>
                        </div>
                        <div>
                            <h6 class="title">{{ ___('subscription.Total_course') }} :</h5>
                            <p>{{ $data['package_detail']->total_course }}</p>
                        </div>
                    </div>
                    <div class="col-xl-12 col-md-12 mt-4">
                        <div class="form-group d-flex justify-content-end">
                            <button class="btn btn-lg ot-btn-primary close-modal" type="button" data-dismiss="modal">{{ ___('common.Discard') }}</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('backend/assets/js/modal/__modal.min.js') }}"></script>
