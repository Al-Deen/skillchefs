<li class="sidebar-menu-item">
    <a class="parent-item-content has-arrow">
        <i class="las la-trophy"></i> <span class="on-half-expanded">{{ ___('backend_sidebar.Subscription') }}</span>
        <span class="badge badge-danger text-white">{{ ___('addon.Addon') }}</span>
    </a>
    <!-- second layer child menu list start  -->
    <ul class="child-menu-list">
        {{-- Start requested subscription --}}
        @if(hasPermission('requested_course_list'))
        <li class="sidebar-menu-item {{ set_menu(['subscription.admin.requested_course']) }}">
            <a
                href="{{ route('subscription.admin.requested_course') }}">{{ ___('subscription.Requested_Course') }}</a>
        </li>
        @endif
        {{-- End requested subscription --}}
        {{-- Start approved subscription --}}
        @if(hasPermission('approved_course_list'))
        <li class="sidebar-menu-item {{ set_menu(['subscription.admin.approved_course']) }}">
            <a href="{{ route('subscription.admin.approved_course') }}">{{ ___('subscription.Approved_Course') }}</a>
        </li>
        @endif
        {{-- End approved subscription --}}
        {{-- Start rejected subscription --}}
        @if(hasPermission('rejected_course_list'))
        <li class="sidebar-menu-item {{ set_menu(['subscription.admin.rejected_course']) }}">
            <a href="{{ route('subscription.admin.rejected_course') }}">{{ ___('subscription.Rejected_Course') }}</a>
        </li>
        @endif
        {{-- End rejected subscription --}}

        {{-- Start package duration type --}}
        @if(hasPermission('package_duration_type_read'))
        <li class="sidebar-menu-item {{ set_menu(['subscription.admin.package_duration_type.index']) }}">
            <a href="{{ route('subscription.admin.package_duration_type.index') }}">{{ ___('subscription.Package_Duration_Type') }}</a>
        </li>
        @endif
        {{-- End package duration type --}}

        {{-- Start package --}}
        @if (hasPermission('package_read'))
        <li class="sidebar-menu-item {{ set_menu(['subscription.admin.package.index','admin/package/create']) }}">
            <a href="{{ route('subscription.admin.package.index') }}">{{ ___('subscription.Package_List') }}</a>
        </li>
        @endif
        {{-- End package --}}
        @if (hasPermission('package_purchase_read'))
        <li class="sidebar-menu-item {{ set_menu(['subscription.admin.package_purchase.index']) }}">
            <a href="{{ route('subscription.admin.package_purchase.index') }}">{{ ___('subscription.Package_Purchase_List') }}</a>
        </li>
        @endif
    </ul>
</li>
