@extends('backend.master')
@section('title')
    {{ @$data['title'] }}
@endsection
@section('content')
    <div class="page-content">

       {{-- breadecrumb Area S t a r t --}}
       @include('backend.ui-components.breadcrumb', [
        'title' => @$data['title'],
        'routes' => [
            route('dashboard')                  => ___('common.Dashboard'),
            route('subscription.admin.package_duration_type.index')      => ___('subscription.Package_Duration_Type'),
            '#' => @$data['title'],
        ],
        'buttons' => 0,
    ])
    {{-- breadecrumb Area E n d --}}

        <!--  package duration type edit start -->
        <div class="card ot-card">
            <div class="card-body">
                <form action="{{ route('subscription.admin.package_duration_type.update', $data['type']->id) }}" enctype="multipart/form-data" method="post">
                    @method('PUT')
                    @csrf
                    {{-- Style Two --}}
                    <div class="row mb-3">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-xl-6 col-md-6 mb-3">
                                    <label for="name" class="form-label ">{{ ___('common.Package_Duration_Type_Name') }} <span class="fillable">*</span></label>
                                    <input class="form-control ot-input @error('name') is-invalid @enderror" name="name" list="datalistOptions" id="name" value="{{ @$data['type']->name }}"
                                        placeholder="{{ ___('placeholder.Enter_Name') }}">
                                    @error('name')
                                        <div id="validationServer04Feedback" class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                                <div class="col-xl-6 col-md-6 mb-3">
                                    <label for="days" class="form-label ">{{ ___('common.Days') }} <span class="fillable">*</span></label>
                                    <input class="form-control ot-input @error('days') is-invalid @enderror" name="days" list="datalistOptions" id="days" value="{{ @$data['type']->days }}"
                                        placeholder="{{ ___('placeholder.Enter_Days') }}">
                                    @error('days')
                                        <div id="validationServer04Feedback" class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-3">
                            <div class="text-left">
                                <button class="btn btn-lg ot-btn-primary" type="submit"></span>{{ @$data['button'] }}</button>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <!--  package duration type edit end -->
    </div>
@endsection
