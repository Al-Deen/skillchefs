@extends('panel.student.layouts.master')
@section('title', @$data['title'])
@section('content')
    <section>
        <div class="row">
            <!-- Section Tittle -->
            <div class="col-xl-12">
                <div class="section-tittle-two d-flex align-items-center justify-content-between flex-wrap mb-10">
                    <h2 class="title font-600 mb-20">{{ $data['title'] }}</h2>
                </div>
            </div>
            <!-- Search -->
        </div>
        <!-- Report Table -->
        <div class="row">
            <div class="col-xl-12">
                <div class="mb-24">
                    <!-- Section Tittle -->
                    <div class="activity-table">
                        <table class="table-responsive">
                            <thead>
                                <tr>
                                    <th>{{ ___('student.Package_Name') }}</th>
                                    <th>{{ ___('frontend.Package_Duration') }}</th>
                                    <th>{{ ___('student.Price') }}</th>
                                    <th>{{ ___('student.Total_Course') }}</th>
                                    <th>{{ ___('student.Course_Enrolled') }}</th>
                                    <th>{{ ___('student.Start_Date') }}</th>
                                    <th>{{ ___('student.Expire_Date') }}</th>
                                    <th>{{ ___('student.Payment_Status') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($data['package_history'] as $package_purchase)
                                    <tr>
                                        <td>
                                            <a target="_blank" href="{{ route('frontend.package.courses', ['package' => @$package_purchase->package->slug]) }}">
                                                {{ @$package_purchase->package_name }}
                                            </a>
                                        </td>
                                        <td>{{ @$package_purchase->package_duration_type->name }}</td>
                                        <td>{{ showPrice(@$package_purchase->amount) }}</td>
                                        <td>
                                            {{ @$package_purchase->total_course }}
                                        </td>
                                        <td>
                                            {{ @$package_purchase->course_enroll }}
                                        </td>
                                        <td class="create-date">{{ showDate(@$package_purchase->start_date) }}</td>
                                        <td class="create-date">
                                            @if(@$package_purchase->expire_date <= now())
                                                <span class="status-danger"> {{ showDate(@$package_purchase->expire_date) }} </span>
                                            @elseif(@$package_purchase->expire_date > now() && @$package_purchase->expire_date <= now()->addDays(7))
                                                <span class="status-pending">{{ showDate(@$package_purchase->expire_date) }}</span>
                                            @else
                                                <span class="status-success">{{ showDate(@$package_purchase->expire_date) }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if(@$package_purchase->status == 'unpaid')
                                            <span class="status-danger">{{ ___('common.Unpaid') }}</span>
                                            @elseif(@$package_purchase->status == 'paid')
                                            <span class="status-success">{{ ___('common.Paid') }}</span>
                                            @else
                                            <span class="status-pending">{{ ___('common.Processing') }}</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="text-center">
                                            {{-- No Data Found --}}
                                            <div class="row justify-content-center">
                                                <div class="col-lg-3 col-md-6 col-sm-6">
                                                    <div class="not-data-found table-img text-center pt-50 pb-10">
                                                        <img src="{{ @showImage(setting('empty_table'), 'backend/assets/images/no-data.png') }}"
                                                            alt="img" class="w-100 mb-20 w-25">
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!--  pagination start -->
        {!! @$data['package_history']->links('frontend.partials.pagination-count') !!}
        <!--  pagination end -->
    </section>
@endsection
