<div class="modal fade boostrap-modal" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content data">
            <div class="modal-body">
                <button type="button" class="close-icon" data-bs-dismiss="modal" aria-label="Close">
                    <i class="ri-close-line" aria-hidden="true"></i>
                </button>
                <div class="custom-modal-body ">
                    <!-- Title -->
                    <div class="small-tittle-two border-bottom mb-30 pb-8">
                        <h4 class="title text-capitalize font-600">{{ $data['title'] }} </h4>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Package_Name') }}</h5>
                        <p>{{ @$data['package']->package->name }}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Package_Duration') }}</h5>
                        <p>{{ @$data['package']->package->package_duration->name }}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Package_Detail') }}</h5>
                        <p>{!! @$data['package']->package->description !!}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Student_Price') }}</h5>
                        <p>{{ showPrice(@$data['package']->package->student_amount) }}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Total_Course') }}</h5>
                        <p>{{ @$data['package']->package->total_course }}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Course_Enrolled') }}</h5>
                        <p>{{ @$data['package']->course_enroll }}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Start_Date') }}</h5>
                        <p>{{ showDate(@$data['package']->start_date) }}</p>
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Expire_Date') }}</h5>
                        @if(@$data['package']->expire_date <= now())
                            <p class="status-danger width-max-content">{{ showDate(@$data['package']->expire_date) }}</p>
                        @elseif(@$data['package']->expire_date > now() && @$data['package']->expire_date <= now()->addDays(7))
                            <p class="status-pending width-max-content">{{ showDate(@$data['package']->expire_date) }}</p>
                        @else
                            <p class="status-success width-max-content">{{ showDate(@$data['package']->expire_date) }}</p>
                        @endif
                    </div>
                    <div class="mb-10">
                        <h6 class="title">{{ ___('subscription.Payment_Status') }}</h5>
                        @if(@$data['package']->status == 'unpaid')
                            <p class="status-danger width-max-content">{{ ___('common.Unpaid') }}</p>
                        @elseif(@$data['package']->status == 'paid')
                            <p class="status-success width-max-content">{{ ___('common.Paid') }}</p>
                        @else
                            <p class="status-pending width-max-content">{{ ___('common.Processing') }}</p>
                        @endif
                    </div>
                    <!-- Close button -->
                    <div class="btn-wrapper d-flex flex-wrap gap-10 mt-20">
                        <button class="btn-primary-outline close-modal"
                            type="button">{{ ___('student.Discard') }}</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('frontend/js/student/__modal.min.js') }}"></script>
