@extends('frontend.layouts.master')
@section('title', @$data['title'] ?? 'Blogs')
@section('content')
    <link rel="stylesheet" type="text/css" href="{{ asset('modules/subscription/css/custom.css') }}">
    <!--Breadcrumb S t a r t -->
    @include('frontend.partials.breadcrumb', [
        'breadcumb_title' => @$data['title'],
    ])
    <!--End-of Breadcrumb  -->
    <!-- Package Area S t a r t -->
    <section class="col-12 section-padding">
        <div class="container">
            <div class="row g-24">
                @foreach ($data['packages'] as $package)
                    <div class="pricing-block col-xl-3 col-lg-4 col-md-6 wow fadeInUp p-10-custom">
                        <div class="inner-box">
                            <a href="{{ route('frontend.package.courses', ['package' => $package->slug]) }}">
                                <div class="icon-box" style="background:{{ @$package->color }}">
                                    <div class="icon-outer">
                                        <i class="fa price_round" style="border:5px solid {{ @$package->color }}; color: {{ @$package->color }}">
                                            {{ showPrice(@$package->student_amount) }}
                                        </i>
                                    </div>
                                </div>
                                <div class="price-box">
                                    <h4 class="price" style="color:{{ @$package->color }}"> {{ Str::limit(@$package->name, @$limit ?? 29) }}</h4>
                                    <div class="title"> {{ @$package->package_duration->name }}</div>
                                </div>
                                <ul class="features">
                                    {!! $package->description !!}
                                    <li><i class="ri-checkbox-circle-fill text-success"></i> {{ @$package->total_course }} Courses</li>
                                </ul>
                            </a>
                            <div class="btn-box">
                                @if(@$package->packagePurchase && @$package->packagePurchase->expire_date > now())
                                    <button class="theme-btn" disabled>{{ ___('frontend.ENROLLED_ALREADY') }}</button>
                                @elseif(@$package->packagePurchase && @$package->packagePurchase->expire_date <= now())
                                    <a href="{{ route('frontend.package.checkout.index', ['package' => $package->slug]) }}" class="theme-btn" style="background:#ff0000;">
                                        {{ ___('frontend.RENEW_PLAN') }}
                                    </a>
                                @else
                                    <a href="{{ route('frontend.package.checkout.index', ['package' => $package->slug]) }}" class="theme-btn" style="background:{{ @$package->color }}">
                                        {{ ___('frontend.BUY_PLAN') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="row">
                <div class="col-lg-12">
                    {{ $data['packages']->links('frontend.layouts.partials.pagination') }}
                </div>
            </div>
        </div>
    </div>
    <!-- End-of Package -->
@endsection
