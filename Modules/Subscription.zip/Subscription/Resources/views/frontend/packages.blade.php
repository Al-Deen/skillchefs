<link rel="stylesheet" type="text/css" href="{{ asset('/modules/subscription/css/custom.css') }}">
<!-- Courses area S t a r t-->
<section class="ot_package_area section-padding " id="ot_package_area" @if(@$section->color) style="background:{{ @$section->color }}" @endif>
    <!-- get data from packages() -->
</section>
<!-- End-Courses area S t a r t-->
