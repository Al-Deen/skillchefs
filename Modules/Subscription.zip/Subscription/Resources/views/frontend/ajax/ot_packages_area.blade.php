<div class="container">
    <div class="row">
        {{-- Section Title --}}
        <div class=" col-xl-12">
            <div class="d-flex align-items-start flex-wrap gap-10 mb-45">
                <div class="section-tittle flex-fill">
                    <h3 class="text-capitalize font-600">{{ $data['title'] }}</h3>
                </div>
                @if($data['package_count'] > 3)
                <a class="btn-primary-fill bisg-btn" href="{{ $data['url'] }}">
                    {{ ___('frontend.See_All') }}
                </a>
                @endif
            </div>
        </div>
        <div class="col-12">
            <div class="course-widget radius-12 h-calc ">
                <div class="widget-mid w-100 ">
                    <section class="pricing-section">
                        <div class="container">
                            <div class="outer-box">
                                <div class="row">
                                    @foreach ($data['packages'] as $package)
                                        <div class="pricing-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                                            @include('subscription::frontend.partials.package_widget', [
                                                'package' => $package,
                                            ])
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
