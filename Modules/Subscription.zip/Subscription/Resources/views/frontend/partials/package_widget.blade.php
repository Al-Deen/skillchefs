<div class="inner-box">
    <a href="{{ route('frontend.package.courses', ['package' => $package->slug]) }}">
        <div class="icon-box" style="background:{{ @$package->color }}">
            <div class="icon-outer">
                <i class="fa price_round" style="border:5px solid {{ @$package->color }}; color: {{ @$package->color }}">
                    {{ showPrice(@$package->student_amount) }}
                </i>
            </div>
        </div>
        <div class="price-box">
            <h4 class="price" style="color:{{ @$package->color }}"> {{ Str::limit(@$package->name, @$limit ?? 29) }}</h4>
            <div class="title"> {{ @$package->package_duration->name }}</div>
        </div>
        <ul class="features">
            {!! $package->description !!}
            <li><i class="ri-checkbox-circle-fill text-success"></i> {{ @$package->total_course }} Courses</li>
        </ul>
    </a>
    <div class="btn-box">
        @if(@$package->packagePurchase && @$package->packagePurchase->status == 'paid' && @$package->packagePurchase->expire_date > now())
            <button class="theme-btn" disabled>{{ ___('frontend.ENROLLED_ALREADY') }}</button>
        @elseif(@$package->packagePurchase && @$package->packagePurchase->expire_date <= now())
            <a href="{{ route('frontend.package.checkout.index', ['package' => $package->slug]) }}" class="theme-btn" style="background:#ff0000;">
                {{ ___('frontend.RENEW_PLAN') }}
            </a>
        @else
            <a href="{{ route('frontend.package.checkout.index', ['package' => $package->slug]) }}" class="theme-btn" style="background:{{ @$package->color }}">
                {{ ___('frontend.BUY_PLAN') }}
            </a>
        @endif
    </div>
</div>
