<?php

namespace Modules\Subscription\Interfaces;

use Illuminate\Http\Request;

interface PackagePurchaseInterface
{
    public function all();

    public function model();

    public function filter($request);

    public function store($request);

    public function renew($request);

    public function updateCourseEnroll($package_id);

}
