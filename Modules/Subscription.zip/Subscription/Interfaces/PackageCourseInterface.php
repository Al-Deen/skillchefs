<?php

namespace Modules\Subscription\Interfaces;

use Illuminate\Http\Request;

interface PackageCourseInterface
{
    public function all();

    public function model();

    public function filter($request);

    public function adminPackageRequest($request);

    public function packageRequest($request);

    public function update($request, $id);

    public function approve($id);

    public function reject($id);

}
