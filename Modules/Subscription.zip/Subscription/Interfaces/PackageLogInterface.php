<?php

namespace Modules\Subscription\Interfaces;

use Illuminate\Http\Request;

interface PackageLogInterface
{
    public function all();

    public function model();

    public function filter($request);

}
