<?php

namespace Modules\Subscription\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PackageLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'package_purchase_id',
        'amount',
        'status',
        'payment_method',
        'payment_details',
        'invoice_number',
        'start_date',
        'expire_date',
        'course_enroll',
        'package_name',
        'package_description',
        'package_duration_type_id',
        'instructor_commission',
        'total_course'
    ];

    protected $casts = [
        'payment_manual' => 'array',
    ];
    
    public function package_purchase(): BelongsTo
    {
        return $this->belongsTo('Modules\Subscription\Entities\PackagePurchase', 'package_purchase_id');
    }

    public function package_duration_type(): BelongsTo
    {
        return $this->belongsTo('Modules\Subscription\Entities\PackageDurationType', 'package_duration_type_id');
    }

    // protected static function newFactory()
    // {
    //     return \Modules\Subscription\Database\factories\PackageLogFactory::new();
    // }
}
