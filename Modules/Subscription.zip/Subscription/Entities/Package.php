<?php

namespace Modules\Subscription\Entities;

use Modules\Course\Entities\Course;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\Relationship\StatusRelationTrait;
use Modules\Subscription\Entities\PackageCourse;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Subscription\Entities\PackageDurationType;

class Package extends Model
{
    use HasFactory, StatusRelationTrait, SoftDeletes;

    protected $fillable = [
        'name',
        'description',
        'package_duration_type_id',
        'student_amount',
        'instructor_amount',
        'popular',
        'status_id',
    ];

    // booted
    protected static function booted()
    {
        static::created(function ($courses) { // when package created then forget cache
            cache()->forget('subscription_packages');
            cache()->forget('subscription_package_all');
        });

        static::updated(function ($courses) { // when package updated then forget cache
            cache()->forget('subscription_packages');
            cache()->forget('subscription_package_all');
        });

        static::deleted(function ($courses) { // when package deleted then forget cache
            cache()->forget('subscription_packages');
            cache()->forget('subscription_package_all');
        });
    }

    public function scopeSearch($query, $search)
    {
        return $query->where('name', 'like', '%' . $search . '%');
    }

    // package duration
    public function package_duration(): BelongsTo
    {
        return $this->belongsTo(PackageDurationType::class, 'package_duration_type_id');
    }

    public function scopeActive($query)
    {
        return $query->where('status_id', 1);
    }

    public function PackageCourses(){
        return $this->hasMany(PackageCourse::class);
    }

    public function PackagePurchase(){
        return $this->hasOne(PackagePurchase::class)->where('user_id', auth()->user()->id ?? null)
                // ->where('status','paid')
                ->select('id','package_id','expire_date');
    }
}
