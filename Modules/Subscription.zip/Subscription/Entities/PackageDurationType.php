<?php

namespace Modules\Subscription\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PackageDurationType extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'days',
    ];

    public function scopeSearch($query, $search)
    {
        return $query->where('name', 'like', '%' . $search . '%');
    }

    // protected static function newFactory()
    // {
    //     return \Modules\Subscription\Database\factories\PackageDurationTypeFactory::new();
    // }
}
