<?php

namespace Modules\Subscription\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;

class PackagePurchase extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'package_id',
        'amount',
        'status',
        'invoice_number',
        'start_date',
        'payment_details',
        'expire_date',
    ];

    protected $casts = [
        'payment_manual' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function package(): BelongsTo
    {
        return $this->belongsTo('Modules\Subscription\Entities\Package', 'package_id');
    }

    public function scopeSearch($query, $req)
    {
        if (@$req->search) {
            return $query->whereHas('package', function ($query) use ($req) {
                $query->where('name', 'like', '%' .$req->search . '%');
            });
        }
    }

    public function scopeSlug($query, $req)
    {
        if (@$req) {
            return $query->whereHas('package', function ($query) use ($req) {
                $query->where('slug', $req);
            });
        }
    }
}
