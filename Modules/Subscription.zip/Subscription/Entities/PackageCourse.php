<?php

namespace Modules\Subscription\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Traits\Relationship\StatusRelationTrait;
use Modules\Subscription\Entities\PackageDurationType;
use Modules\Course\Entities\Course;

class PackageCourse extends Model
{
    use HasFactory, StatusRelationTrait;

    protected $fillable = [
        'course_id',
        'package_id',
        'status_id',
    ];

    // subscription courses
    public function course(): BelongsTo
    {
        return $this->belongsTo('Modules\Course\Entities\Course', 'course_id');
    }

    // subscription packages
    public function package(): BelongsTo
    {
        return $this->belongsTo('Modules\Subscription\Entities\Package', 'package_id');
    }

    public function scopeInstructor(){
        return $this->whereHas('course', function ($query) {
            $query->where('instructor_id', auth()->user()->id);
        });
    }

    public function scopeOrganization(){
        return $this->whereHas('course', function ($query) {
            $query->where('created_by', auth()->user()->id);
        });
    }

    public function scopeSearch($query, $search)
    {
        return $query->whereHas('course', function ($query) use ($search) {
            $query->where('title', 'like', '%' . $search . '%');
        })->orWhereHas('package', function ($query) use ($search) {
            $query->where('name', 'like', '%' . $search . '%');
        });
    }

    // scopeFilter
    public function scopeFilter($query, $req)
    {
        $where = [];
        if (@$req && $req != 'undefined' && $req != 'null') {
            $query->whereHas('course', function ($query) use ($req) {
                $query->where('title', 'like', '%' . $req . '%');
            })->orWhereHas('package', function ($query) use ($req) {
                $query->where('name', 'like', '%' . $req . '%');
            });
        }
        return $query->where($where);
    }

    public function scopePending($query)
    {
        return $query->where('status_id', 3);
    }

    public function scopeApproved($query)
    {
        return $query->where('status_id', 4);
    }

    public function scopeRejected($query)
    {
        return $query->where('status_id', 6);
    }

}
