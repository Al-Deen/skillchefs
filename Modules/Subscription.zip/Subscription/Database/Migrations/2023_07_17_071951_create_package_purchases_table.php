<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('package_purchases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('package_id')->constrained('packages')->onDelete('cascade');
            $table->double('amount', 8, 2);
            $table->enum('status', ['unpaid', 'processing', 'paid','failed'])->default('unpaid');
            $table->string('payment_method')->nullable();
            $table->longText('payment_details')->nullable();
            $table->json('payment_manual')->nullable();
            $table->string('invoice_number')->unique();
            $table->timestamp('start_date')->nullable();
            $table->timestamp('expire_date')->nullable();
            $table->smallInteger('course_enroll')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('package_purchases');
    }
};
