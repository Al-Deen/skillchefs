<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('package_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('package_purchase_id')->constrained('package_purchases')->onDelete('cascade');
            $table->double('amount', 8, 2);
            $table->enum('status', ['unpaid', 'processing', 'paid','failed'])->default('unpaid');
            $table->string('payment_method')->nullable();
            $table->text('payment_details')->nullable();
            $table->json('payment_manual')->nullable();
            $table->string('invoice_number')->unique();
            $table->timestamp('start_date')->nullable();
            $table->timestamp('expire_date')->nullable();
            $table->smallInteger('course_enroll')->default(0);

            $table->string("package_name", 255);
            $table->text("package_description");
            $table->foreignId('package_duration_type_id')->constrained('package_duration_types')->onDelete('cascade');
            $table->double('instructor_commission',8,2);
            $table->smallInteger('total_course')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('package_logs');
    }
};
