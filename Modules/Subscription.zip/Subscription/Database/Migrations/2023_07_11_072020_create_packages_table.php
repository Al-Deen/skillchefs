<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->string("name", 255);
            $table->string("slug", 255);
            $table->text("description");
            $table->foreignId('package_duration_type_id')->constrained('package_duration_types')->onDelete('cascade');
            $table->double('student_amount',8,2);
            $table->double('instructor_commission',8,2);
            $table->smallInteger('total_course')->default(0);

            $table->tinyInteger('popular')->default(0)->comment('0 = no popular, 1 = popular');
            $table->string("color", 20);
            $table->foreignId('status_id')->default(1)->constrained('statuses')->onDelete('cascade'); // 1 = active

            $table->foreignId('created_by')->nullable()->constrained('users')->onDelete('cascade');
            $table->foreignId('updated_by')->nullable()->constrained('users')->onDelete('cascade');
            $table->foreignId('deleted_by')->nullable()->constrained('users')->onDelete('cascade');
            $table->softDeletes();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('packages');
    }
};
