<?php

namespace Modules\Subscription\Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Session;

class SubscriptionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \Modules\CMS\Entities\AppHomeSection::create(
            ['title' => 'Packages',
                'snake_title' => 'subscription_packages',
                'order' => 12,
                'color' => '#fbfaf7',
                'type' => 'web',
            ]
        );
        // all for web
        if (@Session()->get('temp_data') || env('APP_TEST')) {
            try {
                // permission add
                $attributes = [
                    'package' => ['read' => 'package_read', 'create' => 'package_create', 'store' => 'package_store', 'update' => 'package_update', 'delete' => 'package_delete'],
                    'package_duration_type' => ['read' => 'package_duration_type_read', 'create' => 'package_duration_type_create', 'store' => 'package_duration_type_store', 'update' => 'package_duration_type_update', 'delete' => 'package_duration_type_delete'],
                    'package_purchase' => ['read' => 'package_purchase_read', 'package_purchase_invoice' => 'package_purchase_invoice', 'package_purchase_history' => 'package_purchase_history'],
                    'course_subscription' => ['requested_course_list' => 'requested_course_list', 'approved_course_list' => 'approved_course_list', 'rejected_course_list' => 'rejected_course_list', 'course_approve' => 'course_approve', 'course_reject' => 'course_reject'],
                ];
                foreach ($attributes as $key => $attribute) {
                    $permission = new Permission();
                    $permission->attribute = $key;
                    $permission->keywords = $attribute;
                    $permission->save();
                }

                // super admin permission add
                $permission = ['package_read', 'package_create', 'package_store', 'package_update', 'package_delete', 'package_duration_type_read', 'package_duration_type_create',
                    'package_duration_type_store', 'package_duration_type_update', 'package_duration_type_delete', 'package_purchase_read', 'package_purchase_invoice', 'package_purchase_history', 'requested_course_list', 'approved_course_list', 'rejected_course_list', 'course_approve', 'course_reject'];

                foreach (\App\Models\User::where('role_id', 1)->get() as $user) {
                    $user->permissions = array_merge($user->permissions, array_values($permission));
                    $user->save();
                }

                // package duration type
                $packageDurationType = [
                    [
                        'name' => 'Yearly',
                        'days' => '365',
                    ],
                    [
                        'name' => 'Half Yealy',
                        'days' => '180',
                    ],
                    [
                        'name' => 'Monthly',
                        'days' => '30',
                    ],
                    [
                        'name' => 'Weekly',
                        'days' => '7',
                    ],
                ];
                foreach ($packageDurationType as $key => $value) {
                    \Modules\Subscription\Entities\PackageDurationType::create($value);
                }

                // package
                $package = [
                    [
                        "name" => "Package 1",
                        "slug" => "package-1-x2niD6eX",
                        "description" => "<ol><li>AnyTime Renew Subscription</li><li>Courses &amp; Tutorials</li><li>Quiz &amp; Certificate</li><li>Auto Enrollment</li></ol>",
                        "package_duration_type_id" => "1",
                        "student_amount" => "2000.00",
                        "instructor_commission" => "20.00",
                        "total_course" => "20",
                        "popular" => "1",
                        "color" => "#00ffff",
                        "status_id" => "1",
                    ],
                    [
                        "name" => "Package 2",
                        "slug" => "package-2-stMcbu9C",
                        "description" => "<ol><li>AnyTime Renew Subscription</li><li>Courses &amp; Tutorials</li><li>Quiz &amp; Certificate</li><li>Auto Enrollment</li></ol>",
                        "package_duration_type_id" => "2",
                        "student_amount" => "1000.00",
                        "instructor_commission" => "15.00",
                        "total_course" => "15",
                        "popular" => "0",
                        "color" => "#4a86e8",
                        "status_id" => "1",
                    ],
                    [
                        "name" => "Package 3",
                        "slug" => "package-3-OsWZLI1c",
                        "description" => "<ol><li>AnyTime Renew Subscription</li><li>Courses &amp; Tutorials</li><li>Quiz &amp; Certificate</li><li>Auto Enrollment</li></ol>",
                        "package_duration_type_id" => "3",
                        "student_amount" => "500.00",
                        "instructor_commission" => "10.00",
                        "total_course" => "10",
                        "popular" => "1",
                        "color" => "#ff9900",
                        "status_id" => "1",
                    ],
                    [
                        "name" => "Package 4",
                        "slug" => "package-4-eaHnKjP0",
                        "description" => "<ol><li>AnyTime Renew Subscription</li><li>Courses &amp; Tutorials</li><li>Quiz &amp; Certificate</li><li>Auto Enrollment</li></ol>",
                        "package_duration_type_id" => "4",
                        "student_amount" => "200.00",
                        "instructor_commission" => "5.00",
                        "total_course" => "5",
                        "popular" => "1",
                        "color" => "#0000ff",
                        "status_id" => "1",
                    ],
                ];
                foreach ($package as $key => $value) {
                    \Modules\Subscription\Entities\Package::create($value);
                }

                // package courses
                $noticeboard = [
                    [
                        'package_id' => 2,
                        'course_id' => 2,
                        'status_id' => 4,
                    ],
                    [
                        'package_id' => 3,
                        'course_id' => 1,
                        'status_id' => 4,
                    ],
                ];

                foreach ($noticeboard as $key => $value) {
                    \Modules\Subscription\Entities\PackageCourse::create($value);
                }
            } catch (\Exception $e) {
                dd($e);
            }
        }
    }
}
