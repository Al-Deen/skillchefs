<?php

namespace Modules\Subscription\Repositories;


use App\Traits\ApiReturnFormatTrait;
use App\Traits\CommonHelperTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Modules\Subscription\Interfaces\PackageCourseInterface;
use Modules\Subscription\Entities\PackageCourse;

class PackageCourseRepository implements PackageCourseInterface
{
    use ApiReturnFormatTrait, CommonHelperTrait;
    private $model;

    public function __construct(PackageCourse $model)
    {
        $this->model = $model;
    }

    public function all()
    {
        try {
            return $this->model->get();
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function model()
    {
        try {
            return $this->model;
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function filter($filter = null)
    {
        $model = $this->model;
        if (@$filter) {
            $model = $this->model->where($filter);
        }
        return $model;
    }

    public function adminPackageRequest($request)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $packageCourseModel = new $this->model; // create new object of model for store data in database table
            $packageCourseModel->package_id = $request->package_id;
            $packageCourseModel->course_id = $request->course_id;
            $packageCourseModel->status_id = 4;
            $packageCourseModel->save(); // save data in database table
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Package_request_sent_successfully.')); // return success response
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            dd($th);
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }
    public function packageRequest($request)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $packageCourseModel = new $this->model; // create new object of model for store data in database table
            $packageCourseModel->package_id = $request->package_id;
            $packageCourseModel->course_id = $request->course_id;
            $packageCourseModel->save(); // save data in database table
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Package_request_sent_successfully.')); // return success response
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }

    public function update($request, $id)
    {

    }

    // admin panel request approval
    public function approve($course_id)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $course = $this->model()->where('course_id', $course_id)->first();
            $course->status_id = 4;
            $course->save();
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Course approved successfully'), [], 200);
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400);
        }
    }

    // admin panel request reject
    public function reject($course_id)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $course = $this->model()->where('course_id', $course_id)->first();
            $course->status_id = 6;
            $course->save();
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Course rejected successfully'), [], 200);
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400);
        }
    }
}
