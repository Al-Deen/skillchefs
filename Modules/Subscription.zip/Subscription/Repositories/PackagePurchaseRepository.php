<?php

namespace Modules\Subscription\Repositories;


use App\Traits\ApiReturnFormatTrait;
use App\Traits\CommonHelperTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Modules\Subscription\Interfaces\PackagePurchaseInterface;
use Modules\Subscription\Entities\PackagePurchase;
use Modules\Subscription\Entities\PackageLog;

class PackagePurchaseRepository implements PackagePurchaseInterface
{
    use ApiReturnFormatTrait, CommonHelperTrait;
    private $model;
    private $packageLogModel;

    public function __construct(PackagePurchase $model, PackageLog $packageLogModel)
    {
        $this->model = $model;
        $this->packageLogModel = $packageLogModel;
    }

    public function all()
    {
        try {
            return $this->model->get();
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function model()
    {
        try {
            return $this->model;
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function filter($filter = null)
    {
        $model = $this->model;
        if (@$filter) {
            $model = $this->model->where($filter);
        }
        return $model;
    }

    public function store($request)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $packagePurchaseModel = new $this->model; // create new object of model for store data in database table
            $packagePurchaseModel->user_id = auth()->user()->id;
            $packagePurchaseModel->package_id = $request['package']->id;
            $packagePurchaseModel->amount = $request['package']->student_amount;
            $packagePurchaseModel->payment_method = $request['payment_method'] ?? 'free';

            if($request['payment_method'] === 'offline'){
                $manual_info = [
                    'payment_type'              => $request['payment_type'],
                    'additional_details'        => $request['additional_details'],
                ];
                $packagePurchaseModel->payment_manual = $manual_info;
            }

            $packagePurchaseModel->invoice_number = $this->generateInvoiceNumber();
            $packagePurchaseModel->start_date = now()->format('Y-m-d H:i:s');
            $packagePurchaseModel->expire_date = Carbon::now()->addDays($request['package']->package_duration->days);
            $packagePurchaseModel->save(); // save data in database table
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Package_purchased_successfully.'), $packagePurchaseModel); // return success response
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }

    public function renew($request)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }

            $packagePurchaseModel = $this->model->where(['package_id' => $request['package']->id , 'user_id' => auth()->user()->id])->first();

            // store data in database table
            $packageLog = new $this->packageLogModel;
            $packageLog->package_purchase_id = $packagePurchaseModel->id;
            $packageLog->amount = $packagePurchaseModel->amount;
            $packageLog->status = $packagePurchaseModel->status;
            $packageLog->payment_method = $packagePurchaseModel->payment_method;
            $packageLog->payment_details = $packagePurchaseModel->payment_details;
            $packageLog->payment_manual = $packagePurchaseModel->payment_manual;
            $packageLog->invoice_number = $packagePurchaseModel->invoice_number;
            $packageLog->start_date = $packagePurchaseModel->start_date;
            $packageLog->expire_date = $packagePurchaseModel->expire_date;
            $packageLog->course_enroll = $packagePurchaseModel->course_enroll;
            // store package information
            $packageLog->package_name = $request['package']->name;
            $packageLog->package_description = $request['package']->description;
            $packageLog->package_duration_type_id = $request['package']->package_duration_type_id;
            $packageLog->instructor_commission = $request['package']->instructor_commission;
            $packageLog->total_course = $request['package']->total_course;
            $packageLog->save();

            // update data in database table
            $packagePurchaseModel->amount = $request['package']->student_amount;
            $packagePurchaseModel->payment_method = $request['payment_method'] ?? 'free';
            $packagePurchaseModel->invoice_number = $this->generateInvoiceNumber();
            $packagePurchaseModel->start_date = now()->format('Y-m-d H:i:s');
            $packagePurchaseModel->expire_date = Carbon::now()->addDays($request['package']->package_duration->days);
            $packagePurchaseModel->course_enroll = 0;
            $packagePurchaseModel->save();
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Package_purchased_successfully.'), $packageLog); // return success response
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }

    public function updateCourseEnroll($package_id){

        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $updatePackage = $this->model->where(['package_id' => $package_id, 'user_id' => auth()->user()->id])
                                  ->where('expire_date','>=', now())
                                  ->where('status', 'paid')
                                  ->orderBy('created_at','asc')->first();
            $updatePackage->course_enroll += 1;
            $updatePackage->save();
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Course_enroll_updated_successfully.')); // return success response
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }
}
