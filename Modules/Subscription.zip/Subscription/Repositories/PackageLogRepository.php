<?php

namespace Modules\Subscription\Repositories;


use App\Traits\ApiReturnFormatTrait;
use App\Traits\CommonHelperTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Modules\Subscription\Interfaces\PackageLogInterface;
use Modules\Subscription\Entities\PackageLog;

class PackageLogRepository implements PackageLogInterface
{
    use ApiReturnFormatTrait, CommonHelperTrait;
    private $model;

    public function __construct(PackageLog $model)
    {
        $this->model = $model;
    }

    public function all()
    {
        try {
            return $this->model->get();
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function model()
    {
        try {
            return $this->model;
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function filter($filter = null)
    {
        $model = $this->model;
        if (@$filter) {
            $model = $this->model->where($filter);
        }
        return $model;
    }
}
