<?php

namespace Modules\Subscription\Repositories;


use App\Traits\ApiReturnFormatTrait;
use App\Traits\CommonHelperTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Modules\Subscription\Interfaces\PackageDurationTypeInterface;
use Modules\Subscription\Entities\PackageDurationType;

class PackageDurationTypeRepository implements PackageDurationTypeInterface
{
    use ApiReturnFormatTrait, CommonHelperTrait;
    private $model;

    public function __construct(PackageDurationType $model)
    {
        $this->model = $model;
    }

    public function all()
    {
        try {
            return $this->model->get();
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function model()
    {
        try {
            return $this->model;
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function filter($filter = null)
    {
        $model = $this->model;
        if (@$filter) {
            $model = $this->model->where($filter);
        }
        return $model;
    }

    public function store($request)
    {
        DB::beginTransaction(); // start database transaction
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $packageDurationTypeModel = new $this->model; // create new object of model for store data in database table
            $packageDurationTypeModel->name = $request->name;
            $packageDurationTypeModel->days = $request->days;
            $packageDurationTypeModel->save(); // save data in database table
            DB::commit(); // commit database transaction
            return $this->responseWithSuccess(___('alert.Package_duration_type_created_successfully.')); // return success response
        } catch (\Throwable $th) {
            DB::rollBack(); // rollback database transaction
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }

    public function show($id)
    {
        try {
            return $this->model->find($id);
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function update($request, $id)
    {
        DB::beginTransaction();
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $packageDurationTypeModel = $this->model->find($id);
            if (!$packageDurationTypeModel) {
                return $this->responseWithError(___('alert.Package_duration_type_not_found.'), [], 400);
            }
            $packageDurationTypeModel->name = $request->name;
            $packageDurationTypeModel->days = @$request->days;
            $packageDurationTypeModel->save();
            DB::commit();
            return $this->responseWithSuccess(___('alert.Package_duration_type_updated_successfully.'));
        } catch (\Throwable $th) {
            DB::rollBack();
            return $this->responseWithError($th->getMessage(), [], 400);
        }
    }

    public function destroy($id)
    {
        try {
            if (env('APP_DEMO')) {
                return $this->responseWithError(___('alert.you_can_not_change_in_demo_mode'));
            }
            $packageDurationTypeModel = $this->model->find($id);
            $packageDurationTypeModel->delete();
            return $this->responseWithSuccess(___('alert.Package_duration_type_deleted_successfully.')); // return success response
        } catch (\Throwable $th) {
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }
}
