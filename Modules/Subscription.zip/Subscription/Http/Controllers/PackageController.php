<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Subscription\Entities\Package;
use App\Traits\ApiReturnFormatTrait;
use Barryvdh\DomPDF\Facade\Pdf as PDF;
use Modules\Subscription\Http\Requests\PackageRequest;
use Modules\Subscription\Http\Requests\UpdatePackageRequest;
use Modules\Subscription\Interfaces\PackageInterface;
use Modules\Subscription\Interfaces\PackageDurationTypeInterface;
use Modules\Subscription\Interfaces\PackagePurchaseInterface;
use Modules\Subscription\Interfaces\PackageLogInterface;

class PackageController extends Controller
{
    use ApiReturnFormatTrait;

    // constructor injection
    protected $package;
    protected $packageDurationType;
    protected $packagePurchase;
    protected $packageLog;

    public function __construct(PackageInterface $package, PackageDurationTypeInterface $packageDurationType, PackagePurchaseInterface $packagePurchase, PackageLogInterface $packageLog)
    {
        $this->package = $package;
        $this->packageDurationType = $packageDurationType;
        $this->packagePurchase = $packagePurchase;
        $this->packageLog = $packageLog;
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        try {
            $data['packages'] = $this->package->model()->search($request->search)->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Package'); // title
            return view('subscription::panel.admin.package.index', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        try {
            $data['title'] = ___('subscription.Create_Package'); // title
            $data['button'] = ___('common.create'); // button
            $data['type'] = $this->packageDurationType->model()->get(); // data
            return view('subscription::panel.admin.package.create', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(PackageRequest $request)
    {
        try {
            $result = $this->package->store($request);
            if ($result->original['result']) {
                return redirect()->route('subscription.admin.package.index')->with('success', $result->original['message']);
            } else {
                return redirect()->route('subscription.admin.package.index')->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($slug)
    {
        try {
            $data['package_detail'] = $this->package->model()->where('slug', $slug)->first(); // data
            $data['title'] = ___('subscription.Package_Detail'); // title
            $html = view('subscription::panel.admin.partials.modal.package_detail', compact('data'))->render(); // render view
            return $this->responseWithSuccess(___('alert.data_retrieve_success'), $html); // return success response
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
        }
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        try {
            $data['title'] = ___('subscription.Edit_Package'); // title
            $data['button'] = ___('common.update'); // button
            $data['type'] = $this->packageDurationType->model()->get();
            $data['package'] = $this->package->model()->find($id);
            return view('subscription::panel.admin.package.edit', compact('data'));
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }


    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(UpdatePackageRequest $request, $id)
    {
        try {
            $result = $this->package->update($request, $id);
            if ($result->original['result']) {
                return redirect()->route('subscription.admin.package.index')->with('success', $result->original['message']);
            } else {
                return redirect()->route('subscription.admin.package.index')->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        try {
            $result = $this->package->destroy($id);
            if ($result->original['result']) {
                return redirect()->route('subscription.admin.package.index')->with('success', $result->original['message']);
            } else {
                return redirect()->route('subscription.admin.package.index')->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /* package purchase */
    public function indexPackagePurchase(Request $request)
    {
        try {
            $data['package_purchase'] = $this->packagePurchase->model()->search($request)->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Package Purchase'); // title
            return view('subscription::panel.admin.package_purchase_index', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function packagePurchaseInvoice($package_purchase_id)
    {
        try {
            $data['package_purchase'] = $this->packagePurchase->model()->where('id', $package_purchase_id)->first();
            if (!$data['package_purchase']) {
                return redirect()->back()->with('danger', ___('alert.Invoice_not_found'));
            }
            $data['title'] = ___('common.Package_Purchase_Invoice');
            $pdf = PDF::setOptions([
                'isHtml5ParserEnabled' => true,
                'isRemoteEnabled' => true,
            ])->loadView('subscription::panel.admin.invoice.package_purchase_invoice', compact('data'));
            return $pdf->stream('invoice-'.$data['package_purchase']->id.time().'.pdf');
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function packagePurchaseHistory(Request $request, $id){
        try {
            $data['purchase_history'] = $this->packageLog->model()->where('package_purchase_id', $id)->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Package Purchase History'); // title
            return view('subscription::panel.admin.package_purchase_history', compact('data')); // view
        } catch (\Throwable $th) {
            dd($th);
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }
}
