<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\ApiReturnFormatTrait;
use Modules\Subscription\Interfaces\PackageCourseInterface;
use Modules\Subscription\Interfaces\PackageInterface;
use Modules\Course\Interfaces\CourseInterface;
use Modules\Subscription\Http\Requests\InstructorSubscriptionRequest;

class InstructorSubscriptionController extends Controller
{
    use ApiReturnFormatTrait;

    // constructor injection
    protected $packageCourse;
    protected $package;
    protected $course;

    public function __construct(PackageCourseInterface $packageCourse, PackageInterface $package, CourseInterface $course)
    {
        $this->packageCourse = $packageCourse;
        $this->package = $package;
        $this->course = $course;
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        try {
            $data['packages_courses'] = $this->packageCourse->model()->instructor()->search($request->search)->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Course_Subscription'); // title
            return view('subscription::panel.instructor.subscription', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function packageRequest()
    {
        try {
            $data['packages'] = $this->package->model()->where('status_id', 1)->get();  // packages table
            $data['courses'] = $this->course->model()->where(['status_id' => 1, 'instructor_id' => auth()->user()->id])->get(); // course table
            $data['url'] = route('subscription.instructor.package_request_send'); // route
            $data['title'] = ___('instructor.Package_Request_Send'); // title
            @$data['button'] = ___('common.Request'); // button
            $html = view('subscription::modal.instructor.subscription_request', compact('data'))->render(); // render view
            return $this->responseWithSuccess(___('alert.data_retrieve_success'), $html); // return success response
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
        }
    }

    public function adminPackageRequest()
    {
        try {
            $data['packages'] = $this->package->model()->where('status_id', 1)->get();  // packages table
            $data['courses'] = $this->course->model()->where(['status_id' => 1])->get(); // course table
            $data['url'] = route('subscription.admin.package_request_send'); // route
            $data['title'] = ___('common.Add Course'); // title
            @$data['button'] = ___('common.Request'); // button
            $html = view('subscription::modal.instructor.admin_subscription_request', compact('data'))->render(); // render view
            return $this->responseWithSuccess(___('alert.data_retrieve_success'), $html); // return success response
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
        }
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function packageRequestSend(InstructorSubscriptionRequest $request)
    {
        try {
            $result = $this->packageCourse->packageRequest($request);
            if ($result->original['result']) {
                return $this->responseWithSuccess($result->original['message']); // return success response
            } else {
                return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
            }
        } catch (\Throwable $th) {
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }
    public function adminPackageRequestSend(InstructorSubscriptionRequest $request)
    {
        try {
            $result = $this->packageCourse->adminPackageRequest($request);
            if ($result->original['result']) {
                return $this->responseWithSuccess($result->original['message']); // return success response
            } else {
                return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
            }
        } catch (\Throwable $th) {
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('subscription::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('subscription::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
