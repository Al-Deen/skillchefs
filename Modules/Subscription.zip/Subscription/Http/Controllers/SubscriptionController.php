<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Subscription\Entities\PackageCourse;
use App\Traits\ApiReturnFormatTrait;
use Modules\Subscription\Interfaces\PackageCourseInterface;

class SubscriptionController extends Controller
{
    use ApiReturnFormatTrait;

    protected $packageCourse;

    public function __construct(PackageCourseInterface $packageCourse)
    {
        $this->packageCourse = $packageCourse;
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function requestedIndex(Request $request)
    {
        try {
            $data['courses'] = $this->packageCourse->model()->filter($request->search)->pending()->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Requested_course'); // title
            return view('subscription::panel.admin.requested_course', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }
    public function approvedIndex(Request $request)
    {
        try {
            $data['courses'] = $this->packageCourse->model()->filter($request->search)->approved()->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Approved_course'); // title
            return view('subscription::panel.admin.approved_course', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function rejectedIndex(Request $request){
        try {
            $data['courses'] = $this->packageCourse->model()->filter($request->search)->rejected()->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Rejected_course'); // title
            return view('subscription::panel.admin.rejected_course', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }
    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('subscription::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('subscription::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('subscription::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function approve($course_id)
    {
        try {
            $course = $this->packageCourse->model()->where('course_id', $course_id)->first(); // data
            if (!$course) {
                return redirect()->back()->with('danger', ___('alert.course_not_found'));
            }
            $result = $this->packageCourse->approve($course_id);
            if ($result->original['result']) {
                return redirect()->back()->with('success', $result->original['message']);
            } else {
                return redirect()->back()->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function reject($course_id)
    {
        try {
            $course = $this->packageCourse->model()->where('course_id', $course_id)->first(); // data
            if (!$course) {
                return redirect()->back()->with('danger', ___('alert.course_not_found'));
            }
            $result = $this->packageCourse->reject($course_id);
            if ($result->original['result']) {
                return redirect()->back()->with('success', $result->original['message']);
            } else {
                return redirect()->back()->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
