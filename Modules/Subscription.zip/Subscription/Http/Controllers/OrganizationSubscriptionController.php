<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\ApiReturnFormatTrait;
use Modules\Subscription\Interfaces\PackageCourseInterface;
use Modules\Subscription\Interfaces\PackageInterface;
use Modules\Course\Interfaces\CourseInterface;
use Modules\Subscription\Http\Requests\InstructorSubscriptionRequest;

class OrganizationSubscriptionController extends Controller
{
    use ApiReturnFormatTrait;

    // constructor injection
    protected $packageCourse;
    protected $package;
    protected $course;

    public function __construct(PackageCourseInterface $packageCourse, PackageInterface $package, CourseInterface $course)
    {
        $this->packageCourse = $packageCourse;
        $this->package = $package;
        $this->course = $course;
    }

    public function index(Request $request)
    {
        try {
            $data['packages_courses'] = $this->packageCourse->model()->organization()->search($request->search)->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Course_Subscription'); // title
            return view('subscription::panel.organization.subscription', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function packageRequest()
    {
        try {
            $data['packages'] = $this->package->model()->where('status_id', 1)->get();  // packages table
            $data['courses'] = $this->course->model()->where(['status_id' => 1, 'created_by' => auth()->user()->id])->get(); // course table
            $data['url'] = route('subscription.organization.package_request_send'); // route
            $data['title'] = ___('organization.Package_Request_Send'); // title
            @$data['button'] = ___('common.Request'); // button
            $html = view('subscription::modal.organization.subscription_request', compact('data'))->render(); // render view
            return $this->responseWithSuccess(___('alert.data_retrieve_success'), $html); // return success response
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
        }
    }

    public function packageRequestSend(InstructorSubscriptionRequest $request)
    {
        try {
            $result = $this->packageCourse->packageRequest($request);
            if ($result->original['result']) {
                return $this->responseWithSuccess($result->original['message']); // return success response
            } else {
                return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
            }
        } catch (\Throwable $th) {
            return $this->responseWithError($th->getMessage(), [], 400); // return error response
        }
    }
}
