<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Subscription\Entities\PackageDurationType;
use App\Traits\ApiReturnFormatTrait;
use Modules\Subscription\Http\Requests\PackageDurationTypeRequest;
use Modules\Subscription\Http\Requests\UpdatePackageDurationTypeRequest;
use Modules\Subscription\Interfaces\PackageDurationTypeInterface;
class PackageDurationTypeController extends Controller
{
    use ApiReturnFormatTrait;

    // constructor injection
    protected $packageDurationType;

    public function __construct(PackageDurationTypeInterface $packageDurationType)
    {
        $this->packageDurationType = $packageDurationType;
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        try {
            $data['categories'] = $this->packageDurationType->model()->search($request->search)->paginate($request->show ?? 10); // data
            $data['title'] = ___('subscription.Package_Duration_Type'); // title
            return view('subscription::panel.admin.package_duration_type.index', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        try {
            $data['title'] = ___('subscription.Create_Package_Duration_Type'); // title
            $data['button'] = ___('common.create'); // button
            return view('subscription::panel.admin.package_duration_type.create', compact('data')); // view
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function store(PackageDurationTypeRequest $request)
    {
        try {
            $result = $this->packageDurationType->store($request);
            if ($result->original['result']) {
                return redirect()->route('subscription.admin.package_duration_type.index')->with('success', $result->original['message']);
            } else {
                return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('subscription::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        try {
            $data['title'] = ___('subscription.Edit_Package_Duration_Type'); // title
            $data['button'] = ___('common.update'); // button
            $data['type'] = $this->packageDurationType->model()->find($id);
            return view('subscription::panel.admin.package_duration_type.edit', compact('data'));
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(UpdatePackageDurationTypeRequest $request, $id)
    {
        try {
            $result = $this->packageDurationType->update($request, $id);
            if ($result->original['result']) {
                return redirect()->route('subscription.admin.package_duration_type.index')->with('success', $result->original['message']);
            } else {
                return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        try {
            $result = $this->packageDurationType->destroy($id);
            if ($result->original['result']) {
                return redirect()->route('subscription.admin.package_duration_type.index')->with('success', $result->original['message']);
            } else {
                return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', $result->original['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('subscription.admin.package_duration_type.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }
}
