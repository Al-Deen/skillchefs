<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Cache;
use App\Traits\ApiReturnFormatTrait;
use Illuminate\Support\Facades\Redirect;
use Modules\Subscription\Http\Requests\PackageCheckoutRequest;
use Modules\Payment\Interfaces\PaymentInterface;
use Modules\Subscription\Interfaces\PackagePurchaseInterface;
use Modules\Subscription\Interfaces\PackageInterface;
class PackageCheckoutController extends Controller
{
    use ApiReturnFormatTrait;

    private $paymentRepository;
    private $package;
    private $packagePurchase;

    public function __construct(PackageInterface $package, PaymentInterface $paymentRepository, PackagePurchaseInterface $packagePurchase)
    {
        $this->package = $package;
        $this->paymentRepository = $paymentRepository;
        $this->packagePurchase = $packagePurchase;
    }
    /**
     *
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        try {
            $packages = $this->package->model()->with('packagePurchase')->active()->where('slug', $request->package)->first();
            if(!$packages){
                return redirect()->route('home')->with('danger', ___('alert.Invalid_package'));
            }
            if (@$packages->packagePurchase && @$packages->packagePurchase->status == 'paid' && @$packages->packagePurchase->expire_date > now()) {
                return redirect()->route('home')->with('danger', ___('alert.Package_already_purchased'));
            }
            $data['package'] = $packages;
            $data['title'] = ___('frontend.Package_Checkout'); // title
            $data['payment_method'] = $this->paymentRepository->model()->active()->get();
            return view('subscription::frontend.package_checkout', compact('data'));
        } catch (\Throwable $th) {
            return redirect()->route('home')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('subscription::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */

    public function payment(PackageCheckoutRequest $request){
        try {
            if($request->payment_method == 'offline'){
                $payment_method = 'offline';
                $data['payment_type'] = $request->payment_type;
                $data['additional_details'] = $request->additional_details;
            } elseif($request->payment_method == 'Paynet'){
                $payment_method = $request->payment_method;
            } else{
                $payment_method = $request->payment_method ? decrypt($request->payment_method) : null;
            }

            if (!$payment_method) {
                return redirect()->back()->with('danger', ___('alert.Please_select_payment_method'));
            }
            $data['payment_method'] = $payment_method;
            $data['country'] = setting('country') ? setting('country') : 'Bangladesh';

            $package_slug = $request->package_slug ? decrypt($request->package_slug) : null;
            if (!$package_slug) {
                return redirect()->back()->with('danger', ___('alert.Invalid_package'));
            }
            $data['package'] = $this->package->model()->active()->where('slug', $package_slug)->first();
            // package purchase store & renew data
            if($data['package']->packagePurchase){
                $result = $this->packagePurchase->renew($data);
            } else{
                $result = $this->packagePurchase->store($data);
            }

            if($payment_method === 'offline'){
                return redirect()->route('home')->with('success', ___('alert.Payment successfully completed'));
            }

            if ($result->original['result']) {
                try {
                    $payment = $this->paymentRepository->findPaymentMethod($payment_method);

                    if($payment_method == 'Paynet'){
                        $redirect = $payment->package_process($result->original['data'], $request->all());
                    } else{
                        $redirect = $payment->package_process($result->original['data']);
                    }

                    if (in_array($payment_method, $this->paymentRepository->withoutRedirect())) {
                        return $redirect;
                    }
                    return Redirect::away($redirect);
                } catch (\Throwable $th) {
                    return redirect()->route('frontend.package.checkout.index')->with('danger', ___('alert.Payment gateway error'));
                }
            } else {
                return redirect()->back()->with('danger', $result['message']);
            }
        } catch (\Throwable $th) {
            return redirect()->route('frontend.package.checkout.index')->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('subscription::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('subscription::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
