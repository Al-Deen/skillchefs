<?php

namespace Modules\Subscription\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Traits\ApiReturnFormatTrait;
use Illuminate\Support\Facades\Auth;
use Modules\Subscription\Interfaces\PackagePurchaseInterface;
use Modules\Subscription\Interfaces\PackageLogInterface;

class StudentSubscriptionController extends Controller
{
    use ApiReturnFormatTrait;

    // constructor injection
    protected $packagePurchase;
    protected $packageLog;

    public function __construct(PackagePurchaseInterface $packagePurchase, PackageLogInterface $packageLog)
    {
        $this->packagePurchase = $packagePurchase;
        $this->packageLog = $packageLog;
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function packages(Request $request)
    {
        try {
            $data['packages'] = $this->packagePurchase->model()->where('user_id', Auth::id())->where('status','=','paid')->search($request)->latest()->paginate(10);
            $data['title'] = ___('student.My_Packages'); // title
            return view('subscription::panel.student.subscription', compact('data'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    public function packageDetail($slug){
        try {
            $data['package'] = $this->packagePurchase->model()->where('user_id', Auth::id())->slug($slug)->first();
            if (@$data['package']) {
                $data['title'] = ___('course.Package_Detail'); // title
                $html = view('subscription::panel.student.partials.modal.package_detail', compact('data'))->render(); // render view
                return $this->responseWithSuccess(___('alert.data_retrieve_success'), $html); // return success response
            } else {
                return $this->responseWithError(___('alert.Package_Detail_Not_Found'), [], 400); // return error response
            }
        } catch (\Throwable $th) {
            return $this->responseWithError(___('alert.something_went_wrong_please_try_again'), [], 400); // return error response
        }
    }

    public function packageHistory(Request $request, $id){

        try {
            $data['package_purchase'] = $this->packagePurchase->model()->where(['user_id' => Auth::id(), 'id' => $id])->first();
            if(!$data['package_purchase']){
                return redirect()->back()->with('danger', ___('alert.Package_history_not_found'));
            }
            $data['package_history'] = $this->packageLog->model()->where('package_purchase_id', $id)->latest()->paginate(10);
            $data['title'] = ___('student.Package_History'); // title
            return view('subscription::panel.student.package_history', compact('data'));
        } catch (\Throwable $th) {
            return redirect()->back()->with('danger', ___('alert.something_went_wrong_please_try_again'));
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('subscription::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('subscription::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('subscription::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
