<?php

namespace Modules\Subscription\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PackageDurationTypeRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'         => 'required|max:100|unique:package_duration_types,name',
            'days'         => 'required|numeric|between:0,1000',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function messages()
    {
        return [
            'name.required' => ___('validation.name_is_required'),
            'name.max' => ___('validation.name_must_be_less_than_100_characters'),
            'name.unique' => ___('validation.name_must_be_unique'),
            'days.required' => ___('validation.days_is_required'),
            'days.numeric' =>  ___('validation.days_must_be_numeric'),
            'days.between' =>  ___('validation.days_must_be_1_to_1000'),
        ];
    }
}
