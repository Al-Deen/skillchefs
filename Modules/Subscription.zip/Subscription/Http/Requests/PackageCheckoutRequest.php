<?php

namespace Modules\Subscription\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PackageCheckoutRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'payment_method' => 'required|max:255',
            'package_slug' => 'required',
            'payment_type'              => 'required_if:payment_method,offline',
            'additional_details'        => 'required_if:payment_method,offline',

            'card_holder'               => 'required_if:payment_method,Paynet',
            'card_number'               => 'required_if:payment_method,Paynet',
            'cvc'                       => 'required_if:payment_method,Paynet',
            'expiry_date'               => 'required_if:payment_method,Paynet',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, mixed>
     */
    public function messages()
    {
        return [
            'payment_method.required' => ___('alert.Please_select_payment_method'),
            'payment_method.max' => ___('alert.Please_select_valid_payment_method_not_more_than_255_characters'),
            'package_slug.required' => ___('alert.Package_slug_is_required'),
            'payment_type.required_if'              => ___('validation.payment_type_is_required'),
            'additional_details.required_if'        => ___('validation.additional_details_is_required'),

            'card_holder.required_if'        => ___('validation.Card holder or display Name is required'),
            'card_number.required_if'        => ___('validation.Card number is required'),
            'cvc.required_if'                => ___('validation.CVC is required'),
            'expiry_date.required_if'                => ___('validation.Expiry date is required'),
        ];
    }
}

