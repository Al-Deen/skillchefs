<?php

namespace Modules\Subscription\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PackageRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'                      => 'required|max:255|unique:packages,name',
            'description'               => 'required',
            'package_duration_type_id'  => 'required',
            'student_amount'            => 'required|numeric|between:0,10000000',
            'instructor_commission'     => 'required|numeric|between:0,100',
            'total_course'              => 'required|numeric|between:0,1000',
            'popular'                   => 'required',
            'color'                     => 'required',
            'status_id'                 => 'required|max:10|exists:statuses,id',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    public function messages()
    {
        return [
            'name.required'                     => ___('validation.name_is_required'),
            'name.max'                          => ___('validation.name_must_be_less_than_100_characters'),
            'name.unique'                       => ___('validation.name_must_be_unique'),
            'description.required'              => ___('validation.description_is_required'),
            'package_duration_type_id.required' => ___('validation.package_duration_is_required'),

            'student_amount.required'           => ___('validation.student_amount_is_required'),
            'student_amount.numeric'            => ___('validation.student_amount_must_be_numeric'),
            'student_amount.between'            => ___('validation.student_amount_must_be_0_to_10000000'),

            'instructor_commission.required'    => ___('validation.instructor_commission_is_required'),
            'instructor_commission.numeric'     => ___('validation.instructor_commission_must_be_numeric'),
            'instructor_commission.between'     => ___('validation.instructor_commission_must_be_0_to_100'),

            'total_course.required'             => ___('validation.total_course_is_required'),
            'total_course.numeric'              => ___('validation.total_course_must_be_numeric'),
            'total_course.between'              => ___('validation.total_course_must_be_0_to_1000'),

            'popular.required'                  => ___('validation.popular_is_required'),
            'color.required'                    => ___('validation.color_is_required'),

            'status.required'                   => ___('validation.Status_is_required'),
            'status.max'                        => ___('validation.Status_must_be_less_than_10_characters'),
            'status.exists'                     => ___('validation.Status_is_invalid'),
        ];
    }
}
