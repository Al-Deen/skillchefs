<style>
    label {
    display: block;
    font-size: 14px;
    color: #555;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

input:focus {
    border-color: #007BFF;
    outline: none;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007BFF;
    border: none;
    border-radius: 5px;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #0056b3;
}
</style>
<div id="Paynet" class="@if (old('payment_method') == 'Paynet') d-block @else d-none @endif">
    <div class="row">
        <div class="col-lg-6">
            <div class="ot-contact-form mb-24 mt-20">
                <label class="ot-contact-label">Card Holder  <span
                    class="text-danger">*</span></label>
                <input type="text" id="card_holder" name="card_holder" maxlength="40" placeholder="Display Name">
                @error('card_holder')
                    <div id="validationServer04Feedback" class="invalid-feedback d-inline">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <div class="col-lg-6">
            <div class="ot-contact-form mb-24 mt-20">
                <label class="ot-contact-label">Credit Card Number  <span
                    class="text-danger">*</span></label>
                <input type="text" id="card-number" name="card_number" maxlength="19" placeholder="1234 5678 9012 3456">
                @error('card_number')
                    <div id="validationServer04Feedback" class="invalid-feedback d-inline">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>

        <div class="col-lg-6">
            <div class="ot-contact-form mb-24">
                <label class="ot-contact-label">Expiry Date  <span
                    class="text-danger">*</span> </label>
                <input type="text" id="expiry-date" name="expiry_date" placeholder="MM/YY" maxlength="5">
                @error('expiry_date')
                    <div id="validationServer04Feedback" class="invalid-feedback d-inline">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <div class="col-lg-6">
            <div class="ot-contact-form mb-24">
                <label class="ot-contact-label" for="cvc">CVC <span
                    class="text-danger">*</span> </label>
                <input type="password" id="cvc" name="cvc" maxlength="4" >
                @error('cvc')
                    <div id="validationServer04Feedback" class="invalid-feedback d-inline">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
    </div>
</div>
<script>

document.addEventListener('DOMContentLoaded', function () {
    const cardNumberInput = document.getElementById('card-number');
    const expiryDateInput = document.getElementById('expiry-date');
    const cvcInput = document.getElementById('cvc');

    cardNumberInput.addEventListener('input', formatCardNumber);
    expiryDateInput.addEventListener('input', formatExpiryDate);

    function formatCardNumber(e) {
        let input = e.target.value.replace(/\D/g, '').substring(0, 16);
        input = input !== '' ? input.match(/.{1,4}/g).join(' ') : '';
        e.target.value = input;
    }

    function formatExpiryDate(e) {
        let input = e.target.value.replace(/\D/g, '').substring(0, 4);
        if (input.length >= 3) {
            input = `${input.substring(0, 2)}/${input.substring(2, 4)}`;
        }
        e.target.value = input;
    }

    cvcInput.addEventListener('input', function (e) {
        e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
    });

    $('.radio').on('change', function() {
        var event_type = $(this).val();
        if (event_type == "Paynet") {
            $('#Paynet').addClass("d-block").removeClass("d-none");
        } else {
            $('#Paynet').addClass("d-none").removeClass("d-block");
            $("#payment_type option[value='']").attr('selected', true);
            $('#additional_details').val(null);
        }
    });

});


</script>
