<?php

namespace Modules\PaynetGateway\Http\Controllers;

use Illuminate\Http\Request;
use Modules\Order\Entities\Order;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Contracts\Support\Renderable;
use Modules\Event\Entities\EventRegistration;
use Modules\Subscription\Entities\PackagePurchase;

class PaynetGatewayController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    protected $event_id;

    public function __construct()
    {
        $this->event_id = 'stripe.payments.event_id';
    }

    public function process($order, $card_details)
    {
        if(!env('PAYNET_API_URL') && !env('PAYNET_SECRET')){
            return $this->callBackUrl('fail', $order->id);
        }

        list($month, $year) = explode('/', $card_details['expiry_date']);
        $paymentData = [
            'amount' => intval($order->total_amount),
            'reference_no' => $order->invoice_number,
            'domain' => env('APP_URL'),
            'card_holder' => @$card_details['card_holder'],
            'pan' => @$card_details['card_number'],
            'month' => @$month,
            'year' => $year,
            'cvc' =>  @$card_details['cvc'],
        ];

        $apiUrl = env('PAYNET_API_URL','https://pts-api.paynet.com.tr/v2/transaction/payment');
        $secret_key = env('PAYNET_SECRET');
        $response = Http::withHeaders([
            'Accept' => 'application/json; charset=UTF-8',
            'Content-Type' => 'application/json; charset=UTF-8',
            'Authorization' => 'Basic ' . $secret_key,
        ])->post($apiUrl, ($paymentData));

        $result = $response->json();

        // dd($result['code']);
        session()->put('order_id',$order->id);

        if(isset($result) && $result['code'] == 0){
            $order->update([
                'status' => 'processing',
                'payment_details' => json_encode($result)
            ]);
            return $this->callBackUrl('success', $order->id);
        }else{
            $order->update([
                'status' => 'failed',
                'payment_details' => json_encode($result)
            ]);
        }
        return $this->callBackUrl('fail', $order->id);
    }

    public function event_process($event, $card_details)
    {
        if(!env('PAYNET_API_URL') && !env('PAYNET_SECRET')){
            return $this->event_callBackUrl('fail');
        }

        list($month, $year) = explode('/', $card_details['expiry_date']);
        $paymentData = [
            'amount' => intval($event->price),
            'reference_no' => $event->invoice_number,
            'domain' => env('APP_URL'),
            'card_holder' => @$card_details['card_holder'],
            'pan' => @$card_details['card_number'],
            'month' => @$month,
            'year' => $year,
            'cvc' =>  @$card_details['cvc'],
        ];
        $apiUrl = env('PAYNET_API_URL','https://pts-api.paynet.com.tr/v2/transaction/payment');
        $secret_key = env('PAYNET_SECRET');
        $response = Http::withHeaders([
            'Accept' => 'application/json; charset=UTF-8',
            'Content-Type' => 'application/json; charset=UTF-8',
            'Authorization' => 'Basic ' . $secret_key,
        ])->post($apiUrl, ($paymentData));

        $result = $response->json();
        session()->put('event_id', $event->id);
        if(isset($result) && $result['code'] == 0){
            $event->update([
                'status' => 'processing',
                'payment_details' => json_encode($result)
            ]);
            return $this->event_callBackUrl('success');
        }else{
            $event->update([
                'status' => 'failed',
                'payment_details' => json_encode($result)
            ]);
        }
        return $this->event_callBackUrl('fail');
    }

    public function package_process($package, $card_details)
    {
        if(!env('PAYNET_API_URL') && !env('PAYNET_SECRET')){
            return $this->package_callBackUrl('fail');
        }
        list($month, $year) = explode('/', $card_details['expiry_date']);
        $paymentData = [
            'amount' => intval($package->amount),
            'reference_no' => $package->invoice_number,
            'domain' => env('APP_URL'),
            'card_holder' => @$card_details['card_holder'],
            'pan' => @$card_details['card_number'],
            'month' => @$month,
            'year' => $year,
            'cvc' =>  @$card_details['cvc'],
        ];
        $apiUrl = env('PAYNET_API_URL','https://pts-api.paynet.com.tr/v2/transaction/payment');
        $secret_key = env('PAYNET_SECRET');
        $response = Http::withHeaders([
            'Accept' => 'application/json; charset=UTF-8',
            'Content-Type' => 'application/json; charset=UTF-8',
            'Authorization' => 'Basic ' . $secret_key,
        ])->post($apiUrl, ($paymentData));

        $result = $response->json();
        session()->put('package_id', $package->id);

        if(isset($result) && $result['code'] == 0){
            $package->update([
                'status' => 'processing',
                'payment_details' => json_encode($result)
            ]);
            return $this->package_callBackUrl('success');
        }else{
            $package->update([
                'status' => 'failed',
                'payment_details' => json_encode($result)
            ]);
        }
        return $this->package_callBackUrl('fail');
    }

    private function callBackUrl($status, $order_id)
    {
        return url("payments/verify/Paynet?status=$status&session_id=$order_id");
    }

    private function event_callBackUrl($status)
    {
        return url("event_payments/verify/Paynet?status=$status&session_id={CHECKOUT_SESSION_ID}");
    }

    private function package_callBackUrl($status)
    {
        return url("package_payments/verify/Paynet?status=$status&session_id={CHECKOUT_SESSION_ID}");
    }

    public function verify(Request $request)
    {
        $data = $request->all();
        $status = $data['status'];
        $order_id = session()->get('order_id');
        session()->forget('order_id');

        $user = auth()->user();

        $order = Order::where('id', $order_id)
            ->where('user_id', $user->id)
            ->first();


        if ($status == 'success' and !empty($request->session_id) and !empty($order)) {
            $order->update([
                'status' => 'processing',
            ]);
        }else{
            $order->update(['status' =>'failed']);
        }

        return $order;
    }

    public function event_verify(Request $request){
        $data = $request->all();
        $status = $data['status'];
        $event_id = session()->get('event_id');
        session()->forget('event_id');
        $user = auth()->user();
        $event = EventRegistration::where('id', $event_id)->where('user_id', $user->id)->first();
        if ($status == 'success' and !empty($request->session_id) and !empty($event)) {
            $event->update([
                'status' => 'processing',
            ]);
        } else{
            $event->update(['status' =>'failed']);
        }
        return $event;
    }

    public function package_verify(Request $request){
        $data = $request->all();
        $status = $data['status'];
        $package_id = session()->get('package_id');
        session()->forget('package_id');
        $user = auth()->user();
        $package = PackagePurchase::where('id', $package_id)->where('user_id', $user->id)->first();
        if ($status == 'success' and !empty($request->session_id) and !empty($package)) {
            $package->update([
                'status' => 'processing',
            ]);
            return $package;
        } else{
            $package->update(['status' =>'failed']);
        }
        return $package;
    }
}
