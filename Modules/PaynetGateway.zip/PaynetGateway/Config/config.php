<?php

return [
    'name' => 'PaynetGateway'
];
